#include "symbol_table.h"

int main(){
    init_symbol_table();
    clear_symbol_table();
    return 0;
}